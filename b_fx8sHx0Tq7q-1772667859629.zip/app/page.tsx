import { CookieGame } from "@/components/cookie-game"

export default function Page() {
  return <CookieGame />
}
