export interface Upgrade {
  id: string
  name: string
  description: string
  icon: string
  baseCost: number
  cpsIncrease: number
  clickIncrease: number
  owned: number
}

export const UPGRADES: Upgrade[] = [
  {
    id: "cursor",
    name: "Cursor",
    description: "+0.1 cookies/s",
    icon: "pointer",
    baseCost: 15,
    cpsIncrease: 0.1,
    clickIncrease: 0,
    owned: 0,
  },
  {
    id: "grandma",
    name: "Vov\u00f3",
    description: "+1 cookie/s",
    icon: "heart",
    baseCost: 100,
    cpsIncrease: 1,
    clickIncrease: 0,
    owned: 0,
  },
  {
    id: "farm",
    name: "Fazenda",
    description: "+8 cookies/s",
    icon: "wheat",
    baseCost: 1100,
    cpsIncrease: 8,
    clickIncrease: 0,
    owned: 0,
  },
  {
    id: "mine",
    name: "Mina",
    description: "+47 cookies/s",
    icon: "pickaxe",
    baseCost: 12000,
    cpsIncrease: 47,
    clickIncrease: 0,
    owned: 0,
  },
  {
    id: "factory",
    name: "F\u00e1brica",
    description: "+260 cookies/s",
    icon: "factory",
    baseCost: 130000,
    cpsIncrease: 260,
    clickIncrease: 0,
    owned: 0,
  },
  {
    id: "doubleclick",
    name: "Clique Duplo",
    description: "+1 cookie/clique",
    icon: "mouse-pointer-click",
    baseCost: 50,
    cpsIncrease: 0,
    clickIncrease: 1,
    owned: 0,
  },
]

export function getUpgradeCost(upgrade: Upgrade): number {
  return Math.floor(upgrade.baseCost * Math.pow(1.15, upgrade.owned))
}

export function formatNumber(num: number): string {
  if (num >= 1e12) return (num / 1e12).toFixed(1) + " trilh\u00e3o"
  if (num >= 1e9) return (num / 1e9).toFixed(1) + " bilh\u00e3o"
  if (num >= 1e6) return (num / 1e6).toFixed(1) + " milh\u00e3o"
  if (num >= 1e3) return (num / 1e3).toFixed(1) + " mil"
  return Math.floor(num).toString()
}
