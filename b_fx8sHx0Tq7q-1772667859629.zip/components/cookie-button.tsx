"use client"

import { useCallback, useRef, useState } from "react"

interface FloatingText {
  id: number
  x: number
  y: number
  value: number
}

interface CookieButtonProps {
  onClick: () => void
  clickValue: number
}

export function CookieButton({ onClick, clickValue }: CookieButtonProps) {
  const [floatingTexts, setFloatingTexts] = useState<FloatingText[]>([])
  const [isPressed, setIsPressed] = useState(false)
  const nextId = useRef(0)
  const buttonRef = useRef<HTMLButtonElement>(null)

  const handleClick = useCallback(
    (e: React.MouseEvent<HTMLButtonElement>) => {
      onClick()

      const rect = buttonRef.current?.getBoundingClientRect()
      if (rect) {
        const x = e.clientX - rect.left
        const y = e.clientY - rect.top
        const id = nextId.current++
        setFloatingTexts((prev) => [...prev, { id, x, y, value: clickValue }])
        setTimeout(() => {
          setFloatingTexts((prev) => prev.filter((t) => t.id !== id))
        }, 800)
      }

      setIsPressed(true)
      setTimeout(() => setIsPressed(false), 100)
    },
    [onClick, clickValue]
  )

  return (
    <button
      ref={buttonRef}
      onClick={handleClick}
      className="relative select-none focus:outline-none group"
      aria-label={`Clique no cookie para ganhar ${clickValue} cookies`}
    >
      <div
        className={`relative w-52 h-52 md:w-72 md:h-72 lg:w-80 lg:h-80 rounded-full transition-transform duration-100 ${
          isPressed ? "scale-90" : "scale-100 hover:scale-105"
        }`}
      >
        <img
          src="/images/cookie.jpg"
          alt="Cookie gigante"
          className="w-full h-full rounded-full object-cover drop-shadow-[0_0_40px_rgba(180,120,60,0.5)]"
          draggable={false}
        />
        <div className="absolute inset-0 rounded-full bg-primary/0 group-hover:bg-primary/10 transition-colors duration-200" />
      </div>

      {floatingTexts.map((text) => (
        <span
          key={text.id}
          className="absolute text-primary font-bold text-xl md:text-2xl pointer-events-none animate-float-up"
          style={{ left: text.x, top: text.y }}
        >
          +{text.value}
        </span>
      ))}
    </button>
  )
}
