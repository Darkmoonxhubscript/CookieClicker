"use client"

import { useCallback, useEffect, useRef, useState } from "react"
import { CookieButton } from "@/components/cookie-button"
import { UpgradeShop } from "@/components/upgrade-shop"
import { CookieStats } from "@/components/cookie-stats"
import { UPGRADES, getUpgradeCost, type Upgrade } from "@/lib/game-store"
import { ScrollArea } from "@/components/ui/scroll-area"

export function CookieGame() {
  const [cookies, setCookies] = useState(0)
  const [totalCookies, setTotalCookies] = useState(0)
  const [upgrades, setUpgrades] = useState<Upgrade[]>(
    UPGRADES.map((u) => ({ ...u }))
  )
  const cookiesRef = useRef(0)
  const cpsRef = useRef(0)

  const cps = upgrades.reduce(
    (acc, u) => acc + u.cpsIncrease * u.owned,
    0
  )
  const clickValue = upgrades.reduce(
    (acc, u) => acc + u.clickIncrease * u.owned,
    1
  )

  cpsRef.current = cps

  useEffect(() => {
    const interval = setInterval(() => {
      const gain = cpsRef.current / 20
      setCookies((prev) => {
        cookiesRef.current = prev + gain
        return prev + gain
      })
      setTotalCookies((prev) => prev + gain)
    }, 50)
    return () => clearInterval(interval)
  }, [])

  const handleClick = useCallback(() => {
    setCookies((prev) => {
      const val = prev + clickValue
      cookiesRef.current = val
      return val
    })
    setTotalCookies((prev) => prev + clickValue)
  }, [clickValue])

  const handleBuy = useCallback(
    (id: string) => {
      setUpgrades((prev) => {
        const idx = prev.findIndex((u) => u.id === id)
        if (idx === -1) return prev
        const upgrade = prev[idx]
        const cost = getUpgradeCost(upgrade)
        if (cookiesRef.current < cost) return prev
        setCookies((c) => {
          const newVal = c - cost
          cookiesRef.current = newVal
          return newVal
        })
        const newUpgrades = [...prev]
        newUpgrades[idx] = { ...upgrade, owned: upgrade.owned + 1 }
        return newUpgrades
      })
    },
    []
  )

  return (
    <div className="flex flex-col lg:flex-row min-h-dvh">
      {/* Main cookie area */}
      <main className="flex-1 flex flex-col items-center justify-center gap-6 p-6 lg:p-12">
        <CookieStats
          cookies={cookies}
          cps={cps}
          clickValue={clickValue}
          totalCookies={totalCookies}
        />
        <CookieButton onClick={handleClick} clickValue={clickValue} />
        <p className="text-xs text-muted-foreground/50 mt-4">
          Clique no cookie para ganhar mais cookies!
        </p>
      </main>

      {/* Shop sidebar */}
      <aside className="w-full lg:w-80 xl:w-96 border-t lg:border-t-0 lg:border-l border-border bg-card/50">
        <ScrollArea className="h-[40vh] lg:h-dvh">
          <div className="p-4 lg:p-6">
            <UpgradeShop
              upgrades={upgrades}
              cookies={cookies}
              onBuy={handleBuy}
            />
          </div>
        </ScrollArea>
      </aside>
    </div>
  )
}
