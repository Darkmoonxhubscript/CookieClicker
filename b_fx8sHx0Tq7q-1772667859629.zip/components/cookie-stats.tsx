"use client"

import { Cookie, Zap, MousePointerClick } from "lucide-react"
import { formatNumber } from "@/lib/game-store"

interface CookieStatsProps {
  cookies: number
  cps: number
  clickValue: number
  totalCookies: number
}

export function CookieStats({ cookies, cps, clickValue, totalCookies }: CookieStatsProps) {
  return (
    <div className="flex flex-col items-center gap-2 w-full">
      <div className="flex items-center gap-2">
        <Cookie className="w-8 h-8 md:w-10 md:h-10 text-primary" />
        <span className="text-3xl md:text-5xl font-bold text-foreground tabular-nums tracking-tight">
          {formatNumber(cookies)}
        </span>
      </div>
      <p className="text-sm md:text-base text-muted-foreground font-medium">cookies</p>
      <div className="flex items-center gap-4 mt-2">
        <div className="flex items-center gap-1.5 text-xs md:text-sm text-muted-foreground">
          <Zap className="w-3.5 h-3.5 text-accent" />
          <span>{cps.toFixed(1)}/s</span>
        </div>
        <div className="flex items-center gap-1.5 text-xs md:text-sm text-muted-foreground">
          <MousePointerClick className="w-3.5 h-3.5 text-accent" />
          <span>+{clickValue}/clique</span>
        </div>
      </div>
      <p className="text-xs text-muted-foreground/60 mt-1">
        Total: {formatNumber(totalCookies)} cookies produzidos
      </p>
    </div>
  )
}
