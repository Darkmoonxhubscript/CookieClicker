"use client"

import {
  MousePointer,
  Heart,
  Wheat,
  Pickaxe,
  Factory,
  MousePointerClick,
  Lock,
} from "lucide-react"
import { type Upgrade, getUpgradeCost, formatNumber } from "@/lib/game-store"

const iconMap: Record<string, React.ElementType> = {
  pointer: MousePointer,
  heart: Heart,
  wheat: Wheat,
  pickaxe: Pickaxe,
  factory: Factory,
  "mouse-pointer-click": MousePointerClick,
}

interface UpgradeShopProps {
  upgrades: Upgrade[]
  cookies: number
  onBuy: (id: string) => void
}

export function UpgradeShop({ upgrades, cookies, onBuy }: UpgradeShopProps) {
  return (
    <div className="flex flex-col gap-2 w-full">
      <h2 className="text-lg font-bold text-primary mb-1">Loja</h2>
      {upgrades.map((upgrade) => {
        const cost = getUpgradeCost(upgrade)
        const canAfford = cookies >= cost
        const Icon = iconMap[upgrade.icon] || MousePointer

        return (
          <button
            key={upgrade.id}
            onClick={() => canAfford && onBuy(upgrade.id)}
            disabled={!canAfford}
            className={`flex items-center gap-3 p-3 rounded-lg border transition-all duration-200 w-full text-left ${
              canAfford
                ? "border-primary/40 bg-card hover:bg-primary/10 hover:border-primary cursor-pointer"
                : "border-border bg-muted/30 opacity-50 cursor-not-allowed"
            }`}
            aria-label={`Comprar ${upgrade.name} por ${formatNumber(cost)} cookies`}
          >
            <div
              className={`flex items-center justify-center w-10 h-10 rounded-lg shrink-0 ${
                canAfford ? "bg-primary/20 text-primary" : "bg-muted text-muted-foreground"
              }`}
            >
              {canAfford ? <Icon className="w-5 h-5" /> : <Lock className="w-4 h-4" />}
            </div>
            <div className="flex flex-col min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <span className="font-semibold text-sm text-foreground truncate">
                  {upgrade.name}
                </span>
                <span className="text-xs font-medium text-muted-foreground shrink-0">
                  x{upgrade.owned}
                </span>
              </div>
              <span className="text-xs text-muted-foreground">{upgrade.description}</span>
              <span
                className={`text-xs font-bold mt-0.5 ${
                  canAfford ? "text-accent" : "text-muted-foreground"
                }`}
              >
                {formatNumber(cost)} cookies
              </span>
            </div>
          </button>
        )
      })}
    </div>
  )
}
